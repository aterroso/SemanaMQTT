#include <Arduino.h>

#include <WiFi.h>
#include <PubSubClient.h>

#include "SPI.h"
#include "Adafruit_GFX.h"
#include "Adafruit_GC9A01A.h"

#define TFT_DC 2
#define TFT_CS 4

Adafruit_GC9A01A tft(TFT_CS, TFT_DC);

static long long tempo=0;

const char* ssid = "mototerroso";
const char* password = "0123456789";

const char* mqtt_broker = "broker.emqx.io";
const int mqtt_port = 1883;

#define ID_MQTT "TERROSO_SUB"

#define topico_sub_temp "sala206/temp"
#define topico_sub_umid "sala206/umid"

WiFiClient espClient;
PubSubClient MQTT(espClient);

void pinta_fundo();
void escreve_labels();
void conectaWifi();
void conectaMQTT();
void callback(char *topic, byte *payload, unsigned int length);


int flag=0;
void setup() 
{  
  Serial.begin(9600);
  tft.begin();
  pinta_fundo();
  escreve_labels();
  conectaWifi();
  MQTT.setServer(mqtt_broker, mqtt_port);
  MQTT.setCallback(callback);
}

void conectaWifi()
{
  Serial.println("Conectado a rede wifi!");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) 
  {
    delay(500);
    Serial.println("Conectando a rede wifi....");
  }
  Serial.println("Conectado a rede wifi!");
}

void conectaMQTT()
{
  while(!MQTT.connected()) 
  {
    if(MQTT.connect(ID_MQTT))
    {
      Serial.println("Conectado ao Broker!");
      MQTT.subscribe(topico_sub_temp);
      MQTT.subscribe(topico_sub_umid);
    } 
    else 
    {
      Serial.print("Falha na conexão. O status é: ");
      Serial.print(MQTT.state());
      delay(2000);
    }
  }
}

void callback(char *topic, byte *payload, unsigned int length) 
{
  String msg_temp;
  String msg_umid;
  Serial.print("Mensagem recebida do topico ");
  Serial.println(topic);

  if(String(topic) == "sala206/temp")
  {
    for (int i = 0; i < length; i++) 
    {
      Serial.print((char) payload[i]); 
      msg_temp += (char) payload[i];
    }
    tft.fillRect(55, 90, 100, 30, GC9A01A_BLUE);  // limpa só a área do valor
    tft.setTextColor(GC9A01A_YELLOW);  
    tft.setTextSize(3);
    tft.setCursor(55, 90);
    tft.println(msg_temp);        
  }
  else if(String(topic) == "sala206/umid")
  {
    for (int i = 0; i < length; i++) 
    {
      Serial.print((char) payload[i]); 
      msg_umid += (char) payload[i];
    }
    tft.fillRect(70, 160, 100, 30, GC9A01A_BLUE); // limpa só a área do valor
    tft.setTextColor(GC9A01A_YELLOW);  
    tft.setTextSize(3);
    tft.setCursor(70, 160);    
    tft.println(msg_umid);        
  }
}

void loop() 
{
  if(WiFi.status() != WL_CONNECTED) conectaWifi();
  if(!MQTT.connected()) conectaMQTT();
  MQTT.loop();
}

void pinta_fundo()
{
  tft.fillScreen(GC9A01A_BLUE);
  yield();
}

void escreve_labels()
{
  tft.setTextColor(GC9A01A_WHITE);  
  tft.setTextSize(2);
  tft.setCursor(50, 60);
  tft.println("Temperatura: ");
  tft.setCursor(80, 130);
  tft.println("Umidade: ");

  tft.setTextSize(2);
  tft.setCursor(155, 85);
  tft.println("o");
  tft.setTextSize(3);
  tft.setCursor(168, 90);
  tft.println("C");

  tft.setTextSize(3);
  tft.setCursor(170, 160);
  tft.println("%");  
}