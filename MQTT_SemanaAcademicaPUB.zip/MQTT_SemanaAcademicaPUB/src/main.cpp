#include <Arduino.h>

#include <WiFi.h>
#include <PubSubClient.h>

#include <Adafruit_Sensor.h>
#include <DHT.h>

static long long tempo=0;

const char* ssid = "mototerroso";
const char* password = "0123456789";

const char* mqtt_broker = "broker.emqx.io";
const int mqtt_port = 1883;

#define ID_MQTT "TERROSO_PUB"
#define topico_pub_temp "sala206/temp"
#define topico_pub_umid "sala206/umid"

WiFiClient espClient;
PubSubClient MQTT(espClient);

#define pino_DHT 4
#define tipo_DHT DHT22

DHT dht(pino_DHT, tipo_DHT);

void conectaWifi();

void setup() 
{
  dht.begin();
  Serial.begin(9600);
  conectaWifi();
  MQTT.setServer(mqtt_broker, mqtt_port);
}

void conectaWifi()
{
  Serial.println("Conectando a rede wifi!");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) 
  {
    delay(500);
    Serial.println("Conectando a rede wifi....");
  }
  Serial.println("Conectado a rede wifi");
}

void conectaMQTT()
{
  while(!MQTT.connected()) 
  {
    if (MQTT.connect(ID_MQTT))
    {
      Serial.println("Conectado ao Broker!");
    } 
    else 
    {
      Serial.print("Falha na conexão. O status é: ");
      Serial.print(MQTT.state());
      delay(2000);
    }
  }
}
void publicaDados()
{
  float umid = dht.readHumidity();  
  float temp = dht.readTemperature(); 

  MQTT.publish(topico_pub_temp,String(temp).c_str());
  MQTT.publish(topico_pub_umid,String(umid).c_str());
}

void loop() 
{
  static long long pooling = 0;
  if(!MQTT.connected()) conectaMQTT();
  if(WiFi.status() != WL_CONNECTED) conectaWifi();
  
  if(millis()>pooling+3000)
  {
    pooling = millis();
    publicaDados();
  }
  MQTT.loop();
}
